package com.example.calculadora_plus;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.style.TextAppearanceSpan;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    Button btn;
     double n;
    TextView tempVal;
    RadioGroup rgb;
    RadioButton opt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn = findViewById(R.id.btnCalcular);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    tempVal = findViewById(R.id.TxtNum1);
                    Double num1 = Double.parseDouble(tempVal.getText().toString());

                    tempVal = findViewById(R.id.TxtNum2);
                    Double num2 = Double.parseDouble(tempVal.getText().toString());

                    double respuesta = 0.0;

                    opt = findViewById(R.id.optSuma);
                    if (opt.isChecked()) {
                        respuesta = num1 + num2;
                    }
                    opt = findViewById(R.id.optResta);
                    if (opt.isChecked()) {
                        respuesta = num1 - num2;
                    }
                    opt = findViewById(R.id.optMultiplicacion);
                    if (opt.isChecked()) {
                        respuesta = num1 * num2;
                    }
                    opt = findViewById(R.id.optDivision);
                    if (opt.isChecked()) {
                        respuesta = num1 / num2;
                    }
                        opt = findViewById(R.id.optPorcentaje);
                        if (opt.isChecked()) {

                            respuesta = num1 * num2 / 100;

                        }
                     {
                         opt = findViewById(R.id.optRaiz);
                         if (opt.isChecked())
                        respuesta = Math.sqrt(num1);

                    }
                        tempVal = findViewById(R.id.lblRespuesta);
                        tempVal.setText("Respuesta: " + String.format("%.2f", respuesta));


                    

                } finally {

                }
                ;

            };

        });
    };
};
